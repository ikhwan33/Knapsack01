/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tampilan;

/**
 *
 * @author CATUR WARGA COMPUTER
 */

import com.mysql.jdbc.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import mydb.MyDB;

public class EditDataBarang extends javax.swing.JInternalFrame {

    Statement st;
    ResultSet rs;
 
    PreparedStatement pst;
    MyDB db;
   
    DefaultTableModel table;
    public EditDataBarang() {
        db = new MyDB();
        initComponents();
        tampil();
        ID_Barang();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtnamabarang = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtbobot = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txthargabeli = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txthargajual = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtkeuntungan = new javax.swing.JTextField();
        txtjenisbarang = new javax.swing.JComboBox<>();
        txttambah = new javax.swing.JButton();
        txtsimpan = new javax.swing.JButton();
        txtedit = new javax.swing.JButton();
        txtdelete = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txttable = new javax.swing.JTable();
        txtid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Edit Data Barang");
        setPreferredSize(new java.awt.Dimension(619, 400));

        jLabel1.setText("Nama Barang :");

        jLabel2.setText("Jenis Barang :");

        jLabel3.setText("Bobot (KG) :");

        jLabel4.setText("Harga Beli (Rp) :");

        jLabel6.setText("Harga Jual (Rp) :");

        jLabel7.setText("Keuntungan (Rp) :");

        txtjenisbarang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Item", "Pupuk", "Bibit", "Obat Tanaman", "Pakan Ternak" }));
        txtjenisbarang.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtjenisbarangItemStateChanged(evt);
            }
        });

        txttambah.setText("Tambah");
        txttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttambahActionPerformed(evt);
            }
        });

        txtsimpan.setText("Simpan");
        txtsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsimpanActionPerformed(evt);
            }
        });

        txtedit.setText("Edit");
        txtedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txteditActionPerformed(evt);
            }
        });

        txtdelete.setText("Delete");

        txttable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama Barang", "Jenis Barang", "Bobot", "Harga Beli", "Harga Jual", "Keuntungan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(txttable);

        jLabel5.setText("ID Barang :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 583, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtjenisbarang, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtbobot, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 68, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txthargabeli, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                            .addComponent(txthargajual)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(36, 36, 36)
                        .addComponent(txtnamabarang))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(txtkeuntungan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txttambah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtsimpan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtedit, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtdelete, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(309, 309, 309)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnamabarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtjenisbarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txthargabeli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtbobot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txthargajual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdelete)
                    .addComponent(txtedit)
                    .addComponent(txtsimpan)
                    .addComponent(txttambah)
                    .addComponent(txtkeuntungan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtjenisbarangItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtjenisbarangItemStateChanged
        
    }//GEN-LAST:event_txtjenisbarangItemStateChanged
    public void tampil(){
             
        try {
            table = new DefaultTableModel(new String[]{"Nama_Barang","Jenis_Barang","Bobot","Harga_Beli","Harga_Jual","Keuntungan"},0);
            rs = db.selectDB();
            while(rs.next()){        
                table.addRow(new Object[]{rs.getString("Nama_barang"),rs.getString("Jenis_barang"),rs.getString("Bobot"),rs.getString("Harga_beli"),rs.getString("Harga_jual"),rs.getString("Keuntungan")});
            }
        } catch (SQLException ex) {
            Logger.getLogger(EditDataBarang.class.getName()).log(Level.SEVERE, null, ex);
        }
        txttable.setModel(table);
    
    }
   
    public void databaru(){
    DefaultTableModel model = (DefaultTableModel)txttable.getModel();
    model.setRowCount(0);
    ID_Barang();
    tampil();
    
    }
    public void ID_Barang(){
        try {
            rs = db.id();
            if (rs.next()){
                String kode = rs.getString("id_barang").substring(1);
                String number = ""+(Integer.parseInt(kode)+1);
                String nol = "";
                switch (number.length()) {
                    case 1:
                        nol = "00";
                        break;
                    case 2:
                        nol = "0";
                        break;
                    case 3:
                        nol = "";
                        break;
                    default:
                        break;
                }
                txtid.setText("ID"+nol+number);
            }else{
                txtid.setText("ID001");
            }
        } catch (SQLException ex) {
            Logger.getLogger(EditDataBarang.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public void tambah (){
        String idb = txtid.getText();
        String namabg = txtnamabarang.getText();
        String jenisbg = (String) txtjenisbarang.getSelectedItem();
        int bobot = Integer.parseInt(txtbobot.getText());
        double hargab = Double.parseDouble(txthargabeli.getText());
        double hargaj = Double.parseDouble(txthargajual.getText());
        double keuntungan = Double.parseDouble(txtkeuntungan.getText());
        db.tambahdb(idb,namabg, jenisbg, bobot, hargab, hargaj, keuntungan);
        System.out.println("Data Berhasil Disimpan");
    }
    public void simpan (){}
    public void edit (){}
    public void delete (){}
    private void txttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttambahActionPerformed
        // TODO add your handling code here:
        tambah();
        tampil();
    }//GEN-LAST:event_txttambahActionPerformed

    private void txtsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsimpanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsimpanActionPerformed

    private void txteditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txteditActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txteditActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtbobot;
    private javax.swing.JButton txtdelete;
    private javax.swing.JButton txtedit;
    private javax.swing.JTextField txthargabeli;
    private javax.swing.JTextField txthargajual;
    private javax.swing.JTextField txtid;
    private javax.swing.JComboBox<String> txtjenisbarang;
    private javax.swing.JTextField txtkeuntungan;
    private javax.swing.JTextField txtnamabarang;
    private javax.swing.JButton txtsimpan;
    private javax.swing.JTable txttable;
    private javax.swing.JButton txttambah;
    // End of variables declaration//GEN-END:variables



    
}
