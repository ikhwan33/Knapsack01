/*
 *    To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mydb;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author CATUR WARGA COMPUTER
 */
public class MyDB {
    String jdbcDriver = "com.mysql.jdbc.Driver";
    String dbURL = "jdbc:mysql://localhost/db_knapsack";
    String user = "root";
    String pass = "";
    
    Connection con;
    Statement st;
    ResultSet rs;
    PreparedStatement pst;
    
//    public static void main (String[] args){
//      MyDB mydb = new MyDB();
//      mydb.koneksi();
//    }
    
    public MyDB(){
        try {
            Class.forName(jdbcDriver);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            con = (Connection) DriverManager.getConnection(dbURL,user,pass);
           
        } catch (SQLException ex) {
            Logger.getLogger(MyDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
    public ResultSet selectDB(){
        String sql = "select * from tbl_barang";
        try {
            st = (Statement) con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(MyDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            rs = st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(MyDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
    
    public ResultSet id(){
        String sql = "SELECT * FROM tbl_barang order by id_barang";
        try {
            st = (Statement) con.createStatement();
            rs = st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(MyDB.class.getName()).log(Level.SEVERE, null, ex);
        }
      return rs;   
    }
   
    public void tambahdb (String idb,String namabg, String jenisbg, int bobot, double hargab, double hargaj, double keuntungan){
       
        try {
            String sql = "INSERT INTO tbl_barang( Id_barang,Jenis_barang, Nama_barang, Bobot, Harga_beli, Harga_jual, Keuntungan) VALUES (?,?,?,?,?,?,?)";
            pst = con.prepareStatement(sql);
            pst.setString(1,idb);
            pst.setString(2,namabg);
            pst.setString(3,jenisbg);
            pst.setInt(4,bobot);
            pst.setDouble(5,hargab);
            pst.setDouble(6,hargaj);
            pst.setDouble(7,keuntungan);
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(MyDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
